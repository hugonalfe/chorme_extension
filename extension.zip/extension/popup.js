
let iframe;
let iframe_url = 'https://nalfe.com';
let width = 360;
let height = 400;

let iframe_onload = function () {
    let loading = document.getElementsByClassName('lds-ring')[0];
    loading.remove();
}

window.onload = function () {   
    setTimeout(function () {
        let group = document.getElementsByClassName('group_iframe')[0];
        let i = document.createElement('iframe');
        i.frameBorder = 0;
        i.width = width;
        i.height = height;
        i.src = iframe_url;
        i.onload = iframe_onload;
        iframe = group.appendChild(i);
    }, 100);
}